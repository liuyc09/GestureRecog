/****************************************************************************
** Meta object code from reading C++ file 'maskselection.h'
**
** Created: Mon Feb 18 19:38:28 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../GesturePasswords/src/maskselection.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'maskselection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MaskSelection[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x08,
      39,   14,   14,   14, 0x08,
      55,   14,   14,   14, 0x08,
      66,   14,   14,   14, 0x08,
      81,   14,   14,   14, 0x08,
      95,   14,   14,   14, 0x08,
     110,   14,   14,   14, 0x08,
     133,  127,   14,   14, 0x08,
     148,  127,   14,   14, 0x08,
     163,  127,   14,   14, 0x08,
     180,  127,   14,   14, 0x08,
     195,  127,   14,   14, 0x08,
     210,  127,   14,   14, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MaskSelection[] = {
    "MaskSelection\0\0processColorDetection()\0"
    "showHistogram()\0setImage()\0toggleCamera()\0"
    "updateTimer()\0setThreshold()\0"
    "beginDetection()\0value\0setMinHue(int)\0"
    "setMinSat(int)\0setMinValue(int)\0"
    "setMaxHue(int)\0setMaxSat(int)\0"
    "setMaxValue(int)\0"
};

void MaskSelection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MaskSelection *_t = static_cast<MaskSelection *>(_o);
        switch (_id) {
        case 0: _t->processColorDetection(); break;
        case 1: _t->showHistogram(); break;
        case 2: _t->setImage(); break;
        case 3: _t->toggleCamera(); break;
        case 4: _t->updateTimer(); break;
        case 5: _t->setThreshold(); break;
        case 6: _t->beginDetection(); break;
        case 7: _t->setMinHue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->setMinSat((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->setMinValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->setMaxHue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->setMaxSat((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->setMaxValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MaskSelection::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MaskSelection::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MaskSelection,
      qt_meta_data_MaskSelection, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MaskSelection::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MaskSelection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MaskSelection::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MaskSelection))
        return static_cast<void*>(const_cast< MaskSelection*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MaskSelection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
